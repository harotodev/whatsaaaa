## 1.1.3 (2021-07-15)


### Bug Fixes

* adicionado novas opções do webhook ([#26](https://github.com/wppconnect-team/server-cli/issues/26)) ([d08093f](https://github.com/wppconnect-team/server-cli/commit/d08093ffa98adc8620777184542747b764a36f78))



# Changelog

### [1.1.2](https://www.github.com/wppconnect-team/server-cli/compare/v1.1.1...v1.1.2) (2021-07-07)


### Bug Fixes

* Corrigido impressão no console quando o frontend está ativo ([3143253](https://www.github.com/wppconnect-team/server-cli/commit/3143253f9bdb140ab23d4d94b02aaa8dfcd0aa73))

## [1.1.1](https://github.com/wppconnect-team/server-cli/compare/v1.1.0...v1.1.1) (2021-06-21)

### Bug Fixes

- Corrigido dependência de biblioteca na instalação ([87e9ec3](https://github.com/wppconnect-team/server-cli/commit/87e9ec38c993c6dce0327ab1c14c3b953bd94cc7))

# [1.1.0](https://github.com/wppconnect-team/server-cli/compare/v1.0.0...v1.1.0) (2021-06-19)

### Features

- Adicionado opção de instalar separadamente o frontend ([ce1950e](https://github.com/wppconnect-team/server-cli/commit/ce1950e8df87ba5b1a9f1b9ef58ba24ddc9f5bb6))

# 1.0.0 (2021-06-14)
